function [SRBM] = generateCorrectedSRBMR(M, N, S, K)
%GENERATESRBM Generate MxN (1,s)-sparse random binary matrix

SRBM = zeros(M,N);
for i=1:N
    ones_indices = randperm(M, S);
    SRBM(ones_indices,i) = 1;
end
r = rank(SRBM);
    
while(r ~= M && M>=N && S~=M)
    SRBM = zeros(M,N);
    for i=1:N
        ones_indices = randperm(M, S);
        SRBM(ones_indices,i) = 1;
    end
    r = rank(SRBM);
end

for j=1:M
    nb_ones = sum(SRBM(j,:));
    for i=1:N
        if (SRBM(j,i) == 1)
            SRBM(j,i) = (K/(K+1))^(nb_ones-1);
            nb_ones = nb_ones-1;
        end
    end
    
end


function [SRBM] = generateCorrectedSRBME(M, N, S, K)
%GENERATESRBM Generate MxN (1,s)-sparse random binary matrix

if (M==S)
    error("Number of ones per column equal to number of columns. Can't generate full-rank matrix.");
elseif (M>N)
    error("Matrix dimensions incorrect for compression.");
end

r=0;
nb_ones = ceil(S/M*N);
while(r ~= M)
    SRBM = zeros(M,N);
    for i=1:M
        ones_indices = randperm(N, nb_ones);
        ones_indices = sort(ones_indices);
        for j=1:nb_ones
            SRBM(i,ones_indices(j)) = (K/(K+1))^(nb_ones-j);
        end
    end
    r = rank(SRBM);
end


